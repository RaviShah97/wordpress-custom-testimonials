<?php
/**
 * Plugin Name: Custom Testimonials
 * Description: Adds a custom post type for testimonials.
 * Version: 1.0.0
 * Author: Ravi
 * Author URI: https://vistavibes.in
 * License: GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

function custom_testimonials_register_post_type() {
    $labels = array(
        'name' => 'Testimonials',
        'singular_name' => 'Testimonial',
        'add_new' => 'Add New Testimonial',
        'add_new_item' => 'Add New Testimonial',
        'edit_item' => 'Edit Testimonial',
        'new_item' => 'New Testimonial',
        'view_item' => 'View Testimonial',
        'search_items' => 'Search Testimonials',
        'not_found' => 'No Testimonials found',
        'not_found_in_trash' => 'No Testimonials in the trash',
        'parent_item_colon' => '',
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor'),
        'menu_icon' => 'dashicons-testimonial',
        'template' => array(
            array('core/single-testimonials', array()),
        ),
        'rewrite' => array('slug' => 'testimonials'), // Adjust the slug as needed
    );

    register_post_type('testimonials', $args);
}

add_action('init', 'custom_testimonials_register_post_type');

function custom_testimonials_add_meta_boxes() {
    // Updated meta box names and descriptions
    add_meta_box('testimonial_author', 'Name of Person Giving Testimonial', 'custom_testimonials_meta_box_author', 'testimonials');
    add_meta_box('testimonial_website', 'Website of Person Giving Testimonial (Optional)', 'custom_testimonials_meta_box_website', 'testimonials');
}
add_action('add_meta_boxes_testimonials', 'custom_testimonials_add_meta_boxes');

function custom_testimonials_meta_box_author($post) {
    // Updated input field name
    $author_name = get_post_meta($post->ID, 'author_name', true);
    echo '<label for="author_name">Name:</label>';
    echo '<input type="text" name="author_name" id="author_name" value="' . esc_attr($author_name) . '" size="50" />';
}

function custom_testimonials_meta_box_website($post) {
    // Updated input field name
    $website_url = get_post_meta($post->ID, 'website_url', true);
    echo '<label for="website_url">Website URL:</label>';
    echo '<input type="text" name="website_url" id="website_url" value="' . esc_attr($website_url) . '" size="50" />';
}

function custom_testimonials_save_meta_boxes($post_id) {
    if (!empty($_POST['author_name'])) {
        update_post_meta($post_id, 'author_name', sanitize_text_field($_POST['author_name']));
    }
    if (!empty($_POST['website_url'])) {
        update_post_meta($post_id, 'website_url', sanitize_text_field($_POST['website_url']));
    }
}
add_action('save_post', 'custom_testimonials_save_meta_boxes');

function custom_testimonials_shortcode($atts) {
    $args = array(
        'post_type' => 'testimonials',
    );

    if (!empty($atts['count'])) {
        $args['posts_per_page'] = (int) $atts['count'];
    }

    $testimonials = new WP_Query($args);

    if ($testimonials->have_posts()) {
        $output = '<div class="testimonials">';
        while ($testimonials->have_posts()) {
            $testimonials->the_post();

            $author_name = get_post_meta(get_the_ID(), 'author_name', true);
            $website_url = get_post_meta(get_the_ID(), 'website_url', true);

            $output .= '<div class="testimonial">';
            $output .= '<h3>' . get_the_title() . '</h3>';
            $output .= '<p>' . get_the_content() . '</p>';
            $output .= '<p class="author"> - ' . $author_name;
            if (!empty($website_url)) {
                $output .= ', <a href="' . esc_url($website_url) . '">' . $website_url . '</a>';
            }
            $output .= '</p>';
            $output .= '</div>';
        }
        wp_reset_postdata();
        $output .= '</div>';
    } else {
        $output = '<p>No testimonials found.</p>';
    }

    return $output;
}
add_shortcode('testimonials', 'custom_testimonials_shortcode');

function custom_testimonials_enqueue_styles() {
    wp_enqueue_style('custom-testimonials-styles', plugin_dir_url(__FILE__) . 'custom-testimonials-styles.css');
}
add_action('wp_enqueue_scripts', 'custom_testimonials_enqueue_styles');
